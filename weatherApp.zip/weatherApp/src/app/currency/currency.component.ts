import { Component, OnInit } from '@angular/core';
import { SharedService } from "./../shared.service";
 
@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styles: [] 
})
export class CurrencyComponent implements OnInit {
  
  id_currency: string = "";
  my_result: any;
  is_success:string;
  timestamp:number;
  base:string;
  date:Date;
  rates:string;
  from:string;
  to:string;
  amount:number;
  convertedAmount:number;
  convertCurrencyArea:boolean=false;
  result:string;
  constructor(private _sharedService: SharedService) {
  }
 
  ngOnInit() {
  }
 
  callCurrencyService() {  
    this._sharedService.getCurrencyExchRate(this.id_currency.toUpperCase())
      .subscribe(
      lstresult => { 
               this.my_result = JSON.stringify(lstresult); 
              this.is_success=lstresult["success"];
               this.timestamp=lstresult["timestamp"];
               this.base=lstresult["base"];
               this.date=lstresult["date"];
               //rates is comming in json format
               this.rates=JSON.stringify(lstresult["rates"]);

      },
      error => {
        console.log("Error. The callCurrencyService result JSON value is as follows:");
        console.log(error);
      }
      ); 
  }
  /*json response of conversion api
  {
    "success": true,
    "query": {
        "from": "GBP",
        "to": "JPY",
        "amount": 25
    },
    "info": {
        "timestamp": 1519328414,
        "rate": 148.972231
    },
    "historical": ""
    "date": "2018-02-22"
    "result": 3724.305775
}*/
//NOTE: logic in the below method is written based on the json response above
  callCurrencyServiceForConversion(){
    this._sharedService.convertCurrency(this.from,this.to,this.amount)
    .subscribe(
    lstresult => { 
            // this.my_result = JSON.stringify(lstresult); 
           // this.is_success=lstresult["success"];
            // this.timestamp=lstresult["timestamp"];
             //this.from=lstresult["query"]["from"];
             //this.to=lstresult["query"]["to"]
             //this.amount=lstresult["query"]["amount"]
             this.convertedAmount=lstresult["result"];
             this.result="yes";


          

    },
    error => {
      console.log("Error. The callCurrencyService result JSON value is as follows:");
      console.log(error);
    }
    ); 

  }
}